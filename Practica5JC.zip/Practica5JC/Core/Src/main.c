/* US/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private variables ---------------------------------------------------------*/
int contador = 0;
int contadorX = 0;
int gan = 0;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void reset_game(void);
void update_leds(int jugador, int contador);
void semaforo_sequence(void);

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();

  /* Infinite loop */
  while (1)
  {
    if (contador == 8) {
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);  // LED de victoria Jugador 1
      gan = 1;
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET); // Apaga semáforo verde
    } else if (contadorX == 8) {
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET);  // LED de victoria Jugador 2
      gan = 1;
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET); // Apaga semáforo verde
    }

    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_0) == GPIO_PIN_RESET) {  // Botón de reinicio
      reset_game();
    }

    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_SET && gan == 0) {
      // Jugador 1
      if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_1) == GPIO_PIN_RESET) {
        HAL_Delay(200);  // Antirrebote
        contador++;
        update_leds(1, contador);
      }

      // Jugador 2
      if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_2) == GPIO_PIN_RESET) {
        HAL_Delay(200);  // Antirrebote
        contadorX++;
        update_leds(2, contadorX);
      }
    }
  }
}

/**
  * @brief  Resetea el juego, apagando los LEDs y restableciendo contadores.
  */
void reset_game(void) {
  // Apaga LEDs de victoria
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);  // LED Jugador 1
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET);  // LED Jugador 2

  // Apaga todos los LEDs de los jugadores
  for (int i = 0; i < 8; i++) {
    HAL_GPIO_WritePin(GPIOA, (1 << i), GPIO_PIN_RESET);  // Jugador 1: PA0-PA7
    HAL_GPIO_WritePin(GPIOB, (1 << i), GPIO_PIN_RESET);  // Jugador 2: PB0-PB7
  }

  // Secuencia de semáforo
  semaforo_sequence();

  // Restablecer contadores
  gan = 0;
  contador = 0;
  contadorX = 0;
}

/**
  * @brief  Actualiza los LEDs de los jugadores según su avance.
  * @param  jugador: 1 para Jugador 1, 2 para Jugador 2
  * @param  contador: Contador del jugador
  */
void update_leds(int jugador, int contador) {
  if (contador > 8) {
    contador = 0;
  }

  GPIO_TypeDef* GPIOx;
  uint16_t pin;

  if (jugador == 1) {
    GPIOx = GPIOA;  // Jugador 1 utiliza PA0-PA7
    pin = (1 << (contador - 1));
  } else {
    GPIOx = GPIOB;  // Jugador 2 utiliza PB0-PB7
    pin = (1 << (contador - 1));
  }

  if (contador > 0) {
    HAL_GPIO_WritePin(GPIOx, pin, GPIO_PIN_SET);
  } else {
    // Apagar todos los LEDs del jugador
    for (int i = 0; i < 8; i++) {
      HAL_GPIO_WritePin(GPIOx, (1 << i), GPIO_PIN_RESET);
    }
  }
}

/**
  * @brief  Realiza la secuencia del semáforo.
  */
void semaforo_sequence(void) {
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);  // Apaga verde
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);    // Enciende rojo
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);  // Apaga rojo
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);    // Enciende amarillo
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);  // Apaga amarillo
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);    // Enciende verde
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pins for LEDs (Jugador 1: PA0-PA7) */
  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
                        GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins for LEDs (Jugador 2: PB0-PB7) */
  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
                        GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* Configure GPIO pins for buttons */
  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2;  // PC0: Semáforo, PC1: Jugador 1, PC2: Jugador 2
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins for semáforo (PA6: Rojo, PA7: Amarillo, PA10: Verde) */
  GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

